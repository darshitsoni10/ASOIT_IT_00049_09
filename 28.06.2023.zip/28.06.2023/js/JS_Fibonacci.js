var x=0,y=-1,z=1,n=0;
while(n<10)
{
    x=y+z;
    document.write(x+"<br>");
    y=z;
    z=x;
    n++;
}