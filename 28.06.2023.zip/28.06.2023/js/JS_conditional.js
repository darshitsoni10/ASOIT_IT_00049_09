var x=20
if (x%2==0)
{
    document.write("X = ",x+" Even number");
}
else
{
    document.write("X = ",x+" Odd Number");
}