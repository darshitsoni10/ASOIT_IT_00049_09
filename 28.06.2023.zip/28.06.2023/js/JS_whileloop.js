x=0;
while (x<10)
{
    document.write(x+"<br>");
    x++;
}