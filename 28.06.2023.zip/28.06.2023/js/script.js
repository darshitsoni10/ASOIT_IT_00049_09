let x=10, y=30;

document.write("X = ",x);
document.write("<br>Y = ",y);
x += 5;
document.write("<br>New X value is :",x+" (using += operator)");
x -= 5;
document.write("<br>New X value is :",x+" (using -= operator)");
x *= 5;
document.write("<br>New X value is :",x+" (using *= operator)");
x /= y;
document.write("<br>New X value is :",x+" (using /= operator)");
x %= y;
document.write("<br>New X value is :",x+" (using %= operator)");
x **= y;
document.write("<br>New X value is :",x+" (using **= operator)<br><br>");

//Array instance of
var a =["Darshit","Dholakia"];
document.write(a instanceof Array);
document.write(" Array Instanceof <br><br>")

//class instance of
class Rectangle{
    constructor(height,width)
    {
        this.height = height;
        this.width = width;
    }
}
var R = new Rectangle(10,20);
document.write(R instanceof Rectangle);
document.write(" Class instanceof <br>");
document.write(R.height+R.width+" Height + Width <br><br> ");

//STRING
let s1="DARSHIT"
let s2="DHOLAKIA"
let s3= s1+" "+s2;
document.write(s3);